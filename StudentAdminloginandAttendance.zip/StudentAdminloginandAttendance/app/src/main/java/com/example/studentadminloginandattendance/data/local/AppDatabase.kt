package com.example.studentadminloginandattendance.data.local

class AppDatabase {
}