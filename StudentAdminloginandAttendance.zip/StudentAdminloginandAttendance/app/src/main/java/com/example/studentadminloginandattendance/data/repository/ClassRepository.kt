package com.example.studentadminloginandattendance.data.repository

class ClassRepository {
}