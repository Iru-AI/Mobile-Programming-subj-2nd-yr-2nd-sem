package com.example.studentadminloginandattendance.domain.usecases

class GetStudentsUseCase {
}