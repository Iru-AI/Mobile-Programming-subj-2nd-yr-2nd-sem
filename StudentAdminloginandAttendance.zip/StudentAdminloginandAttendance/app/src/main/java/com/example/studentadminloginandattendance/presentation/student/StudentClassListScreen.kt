package com.example.studentadminloginandattendance.presentation.student

class StudentClassListScreen {
}