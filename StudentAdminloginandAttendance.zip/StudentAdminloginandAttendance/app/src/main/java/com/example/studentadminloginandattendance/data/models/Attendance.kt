package com.example.studentadminloginandattendance.data.models

class Attendance {
}