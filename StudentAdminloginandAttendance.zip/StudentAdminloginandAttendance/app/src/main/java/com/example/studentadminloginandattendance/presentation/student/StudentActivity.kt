package com.example.studentadminloginandattendance.presentation.student

class StudentActivity {
}