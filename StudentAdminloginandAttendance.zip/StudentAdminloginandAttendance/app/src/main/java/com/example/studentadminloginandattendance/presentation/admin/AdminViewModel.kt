package com.example.studentadminloginandattendance.presentation.admin

class AdminViewModel {
}