package com.example.studentadminloginandattendance.data.repository

class UserRepository {
}