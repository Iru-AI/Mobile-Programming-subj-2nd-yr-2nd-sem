package com.example.studentadminloginandattendance.presentation.login

class LoginActivity {
}