package com.example.studentadminloginandattendance.data.local

class AttendanceDao {
}