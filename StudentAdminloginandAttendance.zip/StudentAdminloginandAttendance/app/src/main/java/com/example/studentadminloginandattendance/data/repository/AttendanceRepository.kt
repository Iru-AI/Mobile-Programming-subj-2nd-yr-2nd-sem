package com.example.studentadminloginandattendance.data.repository

class AttendanceRepository {
}