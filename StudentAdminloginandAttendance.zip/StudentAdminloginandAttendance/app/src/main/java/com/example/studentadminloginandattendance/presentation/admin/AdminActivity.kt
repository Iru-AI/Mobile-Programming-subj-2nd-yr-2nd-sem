package com.example.studentadminloginandattendance.presentation.admin

class AdminActivity {
}