package com.example.studentadminloginandattendance.data.local

class ClassDao {
}