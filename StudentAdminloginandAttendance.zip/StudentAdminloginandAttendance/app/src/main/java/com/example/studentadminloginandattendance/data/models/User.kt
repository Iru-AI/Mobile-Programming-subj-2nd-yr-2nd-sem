package com.example.studentadminloginandattendance.data.models

class User {
}