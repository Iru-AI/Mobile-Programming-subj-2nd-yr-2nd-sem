package com.example.schoolgram.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey val email: String,
    val fullName: String,
    val password: String,
    val role: String,
    val studentId: String? = null
)

