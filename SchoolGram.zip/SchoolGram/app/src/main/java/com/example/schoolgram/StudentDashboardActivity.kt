package com.example.schoolgram

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.schoolgram.databinding.ActivityStudentDashboardBinding

class StudentDashboardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityStudentDashboardBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStudentDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // TODO: Implement student dashboard functionality
    }
}

