package com.example.schoolgram

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.schoolgram.data.AppDatabase
import com.example.schoolgram.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var database: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        database = AppDatabase.getDatabase(this)

        binding.btnLogin.setOnClickListener {
            val studentId = binding.etStudentId.text.toString()
            val password = binding.etPassword.text.toString()

            if (validateInput(studentId, password)) {
                lifecycleScope.launch {
                    val user = database.userDao().login(studentId, password)
                    if (user != null && user.role == "student") {
                        Toast.makeText(this@MainActivity, "Login successful", Toast.LENGTH_SHORT).show()
                        startActivity(Intent(this@MainActivity, StudentDashboardActivity::class.java))
                        finish()
                    } else {
                        Toast.makeText(this@MainActivity, "Invalid credentials", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        binding.btnLoginAsTeacher.setOnClickListener {
            startActivity(Intent(this, TeacherAdminLoginActivity::class.java))
        }

        binding.tvForgotPassword.setOnClickListener {
            Toast.makeText(this, "Forgot password clicked", Toast.LENGTH_SHORT).show()
        }
    }

    private fun validateInput(studentId: String, password: String): Boolean {
        if (studentId.isEmpty()) {
            binding.etStudentId.error = "Student ID is required"
            return false
        }
        if (password.isEmpty()) {
            binding.etPassword.error = "Password is required"
            return false
        }
        return true
    }
}

