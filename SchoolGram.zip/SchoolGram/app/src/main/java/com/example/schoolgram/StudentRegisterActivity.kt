package com.example.schoolgram

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.schoolgram.data.AppDatabase
import com.example.schoolgram.data.User
import com.example.schoolgram.databinding.ActivityStudentRegisterBinding
import kotlinx.coroutines.launch

class StudentRegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityStudentRegisterBinding
    private lateinit var database: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStudentRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        database = AppDatabase.getDatabase(this)

        binding.btnRegister.setOnClickListener {
            val fullName = binding.etFullName.text.toString()
            val email = binding.etEmail.text.toString()
            val studentId = binding.etStudentId.text.toString()
            val password = binding.etPassword.text.toString()
            val confirmPassword = binding.etConfirmPassword.text.toString()

            if (validateInput(fullName, email, studentId, password, confirmPassword)) {
                lifecycleScope.launch {
                    val existingUser = database.userDao().getUserByEmail(email)
                    if (existingUser == null) {
                        val newUser = User(email, fullName, password, "student", studentId)
                        database.userDao().insertUser(newUser)
                        Toast.makeText(this@StudentRegisterActivity, "Registration successful", Toast.LENGTH_SHORT).show()
                        finish()
                    } else {
                        Toast.makeText(this@StudentRegisterActivity, "Email already exists", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        binding.tvLogin.setOnClickListener {
            finish()
        }
    }

    private fun validateInput(fullName: String, email: String, studentId: String, password: String, confirmPassword: String): Boolean {
        if (fullName.isEmpty() || email.isEmpty() || studentId.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show()
            return false
        }
        if (password != confirmPassword) {
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()
            return false
        }
        return true
    }
}

