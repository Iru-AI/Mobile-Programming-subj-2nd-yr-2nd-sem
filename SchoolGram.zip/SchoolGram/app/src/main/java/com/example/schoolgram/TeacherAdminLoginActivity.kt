package com.example.schoolgram

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.schoolgram.data.AppDatabase
import com.example.schoolgram.databinding.ActivityTeacherAdminLoginBinding
import kotlinx.coroutines.launch

class TeacherAdminLoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTeacherAdminLoginBinding
    private lateinit var database: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTeacherAdminLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        database = AppDatabase.getDatabase(this)

        binding.btnLogin.setOnClickListener {
            val email = binding.etEmail.text.toString()
            val password = binding.etPassword.text.toString()

            if (validateInput(email, password)) {
                lifecycleScope.launch {
                    val user = database.userDao().login(email, password)
                    if (user != null && (user.role == "teacher" || user.role == "admin")) {
                        Toast.makeText(this@TeacherAdminLoginActivity, "Login successful", Toast.LENGTH_SHORT).show()
                        startActivity(Intent(this@TeacherAdminLoginActivity, TeacherAdminDashboardActivity::class.java))
                        finish()
                    } else {
                        Toast.makeText(this@TeacherAdminLoginActivity, "Invalid credentials", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        binding.tvRegister.setOnClickListener {
            startActivity(Intent(this, TeacherAdminRegisterActivity::class.java))
        }
    }

    private fun validateInput(email: String, password: String): Boolean {
        if (email.isEmpty()) {
            binding.etEmail.error = "Email is required"
            return false
        }
        if (password.isEmpty()) {
            binding.etPassword.error = "Password is required"
            return false
        }
        return true
    }
}

