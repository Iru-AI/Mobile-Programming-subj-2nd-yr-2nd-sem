package com.example.schoolgram

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.schoolgram.data.AppDatabase
import com.example.schoolgram.data.User
import com.example.schoolgram.databinding.ActivityTeacherAdminRegisterBinding
import kotlinx.coroutines.launch

class TeacherAdminRegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTeacherAdminRegisterBinding
    private lateinit var database: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTeacherAdminRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        database = AppDatabase.getDatabase(this)

        val roles = arrayOf("Teacher", "Admin")
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, roles)
        binding.dropdownRole.setAdapter(adapter)

        binding.btnRegister.setOnClickListener {
            val fullName = binding.etFullName.text.toString()
            val email = binding.etEmail.text.toString()
            val password = binding.etPassword.text.toString()
            val confirmPassword = binding.etConfirmPassword.text.toString()
            val role = binding.dropdownRole.text.toString().toLowerCase()

            if (validateInput(fullName, email, password, confirmPassword, role)) {
                lifecycleScope.launch {
                    val existingUser = database.userDao().getUserByEmail(email)
                    if (existingUser == null) {
                        val newUser = User(email, fullName, password, role)
                        database.userDao().insertUser(newUser)
                        Toast.makeText(this@TeacherAdminRegisterActivity, "Registration successful", Toast.LENGTH_SHORT).show()
                        finish()
                    } else {
                        Toast.makeText(this@TeacherAdminRegisterActivity, "Email already exists", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        binding.tvLogin.setOnClickListener {
            finish()
        }
    }

    private fun validateInput(fullName: String, email: String, password: String, confirmPassword: String, role: String): Boolean {
        if (fullName.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || role.isEmpty()) {
            Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show()
            return false
        }
        if (password != confirmPassword) {
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()
            return false
        }
        if (role != "teacher" && role != "admin") {
            Toast.makeText(this, "Invalid role selected", Toast.LENGTH_SHORT).show()
            return false
        }
        return true
    }
}

