package com.example.schoolgram

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.schoolgram.databinding.ActivityTeacherAdminDashboardBinding

class TeacherAdminDashboardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTeacherAdminDashboardBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTeacherAdminDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // TODO: Implement teacher/admin dashboard functionality
    }
}

