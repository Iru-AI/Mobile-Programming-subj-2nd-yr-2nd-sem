package com.example.fundaproattendance;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import com.example.fundaproattendance.data.AppDatabase;
import com.example.fundaproattendance.databinding.ActivityMainBinding;
import com.example.fundaproattendance.model.User;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class StudentLoginActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private AppDatabase database;
    private ExecutorService executorService = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main);

        database = AppDatabase.getDatabase(this);

        binding.btnLogin.setOnClickListener(v -> {
            String studentId = binding.etStudentId.getText().toString();
            String password = binding.etPassword.getText().toString();

            if (validateInput(studentId, password)) {
                executorService.execute(() -> {
                    User user = database.userDao().login(studentId, password);
                    runOnUiThread(() -> {
                        if (user != null && user.getRole().equals("student")) {
                            Toast.makeText(StudentLoginActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(StudentLoginActivity.this, StudentDashboardActivity.class));
                            finish();
                        } else {
                            Toast.makeText(StudentLoginActivity.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
                        }
                    });
                });
            }
        });

        binding.tvForgotPassword.setOnClickListener(v -> {
            // Handle forgot password logic here
            Toast.makeText(StudentLoginActivity.this, "Forgot password clicked", Toast.LENGTH_SHORT).show();
        });

        binding.btnTeacherAdminLogin.setOnClickListener(v -> {
            // Handle teacher/admin login logic here
            startActivity(new Intent(StudentLoginActivity.this, TeacherAdminLoginActivity.class));
        });
    }

    private boolean validateInput(String studentId, String password) {
        if (TextUtils.isEmpty(studentId)) {
            binding.etStudentId.setError("Student ID is required");
            return false;
        }
        if (TextUtils.isEmpty(password)) {
            binding.etPassword.setError("Password is required");
            return false;
        }
        return true;
    }
}