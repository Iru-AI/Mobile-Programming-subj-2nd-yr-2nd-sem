package com.example.fundaproattendance;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.DatePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.fundaproattendance.data.AppDatabase;
import com.example.fundaproattendance.databinding.StudentDashboardLayoutBinding;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class StudentDashboardActivity extends AppCompatActivity {

    private StudentDashboardLayoutBinding binding;
    private AppDatabase database;
    private Calendar calendar = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Inflate the layout using the generated binding class
        binding = StudentDashboardLayoutBinding.inflate(getLayoutInflater());
        // Set the root view of the binding as the content view
        setContentView(binding.getRoot());

        database = AppDatabase.getDatabase(this);

        // Set the student's name and ID in the welcome card
        // You'll need to retrieve the student's data from the database
        // For example, you might pass the student ID from the login activity
        // and then query the database to get the student's name and ID
        String studentId = "12345"; // Replace with actual student ID
        String studentName = "Student"; // Replace with actual student name
        binding.tvWelcome.setText("Welcome, " + studentName);
        binding.tvStudentId.setText("ID: " + studentId);

        // Handle the date selection
        binding.etAttendanceDate.setOnClickListener(v -> {
            // Show a date picker
            DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                    calendar.set(Calendar.YEAR, year);
                    calendar.set(Calendar.MONTH, monthOfYear);
                    calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                    updateDateLabel();
                }
            };

            new DatePickerDialog(StudentDashboardActivity.this, date, calendar
                    .get(Calendar.YEAR), calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)).show();
        });

        // Handle the "Mark Attendance" button click
        binding.btnMarkAttendance.setOnClickListener(v -> {
            // Handle mark attendance logic here
            Toast.makeText(this, "Mark attendance clicked", Toast.LENGTH_SHORT).show();
        });

        // Set up the bottom navigation
        // You'll need to create a menu resource for the bottom navigation
        // and then set the menu to the BottomNavigationView
        // For example:
        // binding.bottomNavigation.inflateMenu(R.menu.bottom_navigation_menu);
    }

    private void updateDateLabel() {
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        binding.etAttendanceDate.setText(sdf.format(calendar.getTime()));
    }
}