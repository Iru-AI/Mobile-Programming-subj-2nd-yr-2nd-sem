package com.example.fundaproattendance;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import com.example.fundaproattendance.databinding.StudentLayoutBinding;

public class StudentDashboardActivity extends AppCompatActivity {

    private StudentLayoutBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.student_layout);

        // TODO: Implement student dashboard functionality
    }
}