package com.example.fundaproattendance.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.example.fundaproattendance.model.Attendance;

import java.util.List;

@Dao
public interface AttendanceDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAttendance(Attendance attendance);

    @Query("SELECT * FROM attendance WHERE studentId = :studentId AND date = :date")
    Attendance getAttendanceByStudentAndDate(String studentId, String date);

    @Query("SELECT * FROM attendance WHERE date = :date")
    List<Attendance> getAttendanceByDate(String date);

    @Query("SELECT * FROM attendance")
    List<Attendance> getAllAttendance();
}