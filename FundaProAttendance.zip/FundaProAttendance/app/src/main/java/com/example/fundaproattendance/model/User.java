package com.example.fundaproattendance.model;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import androidx.annotation.NonNull;

@Entity(tableName = "users")
public class User {
    @PrimaryKey
    @NonNull
    private String email;
    private String fullName;
    private String password;
    private String role;
    private String studentId;

    public User(@NonNull String email, String fullName, String password, String role, String studentId) {
        this.email = email;
        this.fullName = fullName;
        this.password = password;
        this.role = role;
        this.studentId = studentId;
    }

    @Ignore
    public User(@NonNull String email, String fullName, String password, String role) {
        this(email, fullName, password, role, "");
    }

    @NonNull
    public String getEmail() {
        return email;
    }

    public void setEmail(@NonNull String email) {
        this.email = email;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }
}