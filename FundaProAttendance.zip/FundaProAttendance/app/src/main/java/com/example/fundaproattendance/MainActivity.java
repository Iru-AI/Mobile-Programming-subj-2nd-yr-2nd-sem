package com.example.fundaproattendance;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LifecycleRegistry;
import androidx.lifecycle.lifecycleScope;

import com.example.fundaproattendance.data.AppDatabase;
import com.example.fundaproattendance.databinding.ActivityMainBinding;

import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.launch;
import kotlinx.coroutines.Job;

public class MainActivity extends AppCompatActivity implements LifecycleOwner {

    private ActivityMainBinding binding;
    private AppDatabase database;
    private final LifecycleRegistry lifecycleRegistry = new LifecycleRegistry(this);

    public static final String ROLE_STUDENT = "student";
    public static final String ROLE_TEACHER = "teacher";
    public static final String ROLE_ADMIN = "admin";

    public enum LoginResult {
        SuccessStudent,
        SuccessTeacher,
        SuccessAdmin,
        InvalidCredentials
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main);

        database = AppDatabase.getDatabase(this);

        binding.btn_login.setOnClickListener(v -> {
            String studentId = binding.et_student_id.getText().toString();
            String password = binding.et_password.getText().toString();

            if (validateInput(studentId, password)) {
                CoroutineScope scope = new CoroutineScope(Dispatchers.getIO());
                Job job = scope.launch(Dispatchers.getIO(), (coroutineScope, continuation) -> {
                    LoginResult loginResult = performLogin(studentId, password);
                    runOnUiThread(() -> handleLoginResult(loginResult));
                    return null;
                });
            }
        });

        binding.btn_login_as_teacher.setOnClickListener(v -> {
            startActivity(new Intent(this, TeacherAdminLoginActivity.class));
        });

        binding.tv_forgot_password.setOnClickListener(v -> {
            Toast.makeText(this, "Forgot password clicked", Toast.LENGTH_SHORT).show();
            // Implement forgot password logic here
        });
    }

    private LoginResult performLogin(String studentId, String password) {
        com.google.firebase.firestore.auth.User user = database.userDao().login(studentId, password);
        if (user == null) {
            return LoginResult.InvalidCredentials;
        } else if (user.getRole().equals(ROLE_STUDENT)) {
            return LoginResult.SuccessStudent;
        } else if (user.getRole().equals(ROLE_TEACHER)) {
            return LoginResult.SuccessTeacher;
        } else if (user.getRole().equals(ROLE_ADMIN)) {
            return LoginResult.SuccessAdmin;
        } else {
            return LoginResult.InvalidCredentials;
        }
    }

    private void handleLoginResult(LoginResult loginResult) {
        switch (loginResult) {
            case SuccessStudent:
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, StudentActivity.class));
                finish();
                break;
            case SuccessTeacher:
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, TeacherAdminDashboardActivity.class));
                finish();
                break;
            case SuccessAdmin:
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, AdminTeacherActivity.class));
                finish();
                break;
            case InvalidCredentials:
                Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
                break;
        }
    }

    private boolean validateInput(String studentId, String password) {
        if (TextUtils.isEmpty(studentId)) {
            binding.et_student_id.setError("Student ID is required");
            return false;
        }
        if (TextUtils.isEmpty(password)) {
            binding.et_password.setError("Password is required");
            return false;
        }
        return true;
    }

    @Override
    public Lifecycle getLifecycle() {
        return lifecycleRegistry;
    }
}
