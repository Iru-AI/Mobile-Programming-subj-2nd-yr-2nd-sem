package com.example.fundaproattendance;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import com.example.fundaproattendance.data.AppDatabase;
import com.example.fundaproattendance.data.User;
import com.example.fundaproattendance.databinding.StudentRegisterLayoutBinding;

import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.Job;

public class StudentRegisterActivity extends AppCompatActivity {

    private StudentRegisterLayoutBinding binding;
    private AppDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.student_register_layout);

        database = AppDatabase.getDatabase(this);

        binding.btnRegister.setOnClickListener(v -> {
            String fullName = binding.etFullName.getText().toString();
            String email = binding.etEmail.getText().toString();
            String studentId = binding.etStudentId.getText().toString();
            String password = binding.etPassword.getText().toString();
            String confirmPassword = binding.etConfirmPassword.getText().toString();

            if (validateInput(fullName, email, studentId, password, confirmPassword)) {
                CoroutineScope scope = new CoroutineScope(Dispatchers.getIO());
                Job job = scope.launch(Dispatchers.getIO(), (coroutineScope, continuation) -> {
                    User existingUser = database.userDao().getUserByEmail(email);
                    runOnUiThread(() -> {
                        if (existingUser == null) {
                            User newUser = new User(email, fullName, password, "student", studentId);
                            database.userDao().insertUser(newUser);
                            Toast.makeText(StudentRegisterActivity.this, "Registration successful", Toast.LENGTH_SHORT).show();
                            finish();
                        } else {
                            Toast.makeText(StudentRegisterActivity.this, "Email already exists", Toast.LENGTH_SHORT).show();
                        }
                    });
                    return null;
                });
            }
        });

        binding.tvLogin.setOnClickListener(v -> finish());
    }

    private boolean validateInput(String fullName, String email, String studentId, String password, String confirmPassword) {
        if (TextUtils.isEmpty(fullName) || TextUtils.isEmpty(email) || TextUtils.isEmpty(studentId) || TextUtils.isEmpty(password) || TextUtils.isEmpty(confirmPassword)) {
            Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (!password.equals(confirmPassword)) {
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}