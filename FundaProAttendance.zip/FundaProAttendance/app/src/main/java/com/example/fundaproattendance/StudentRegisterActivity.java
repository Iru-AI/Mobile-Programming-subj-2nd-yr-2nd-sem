package com.example.fundaproattendance;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import com.example.fundaproattendance.data.AppDatabase;
import com.example.fundaproattendance.model.User;
import com.example.fundaproattendance.databinding.StudentRegisterLayoutBinding;

public class StudentRegisterActivity extends AppCompatActivity {

    private StudentRegisterLayoutBinding binding;
    private AppDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.student_register_layout);

        database = AppDatabase.getDatabase(this);

        // Handle the "Register" button click
        binding.btnRegister.setOnClickListener(v -> {
            // Get the values from the input fields
            String fullName = binding.etFullName.getText().toString().trim();
            String email = binding.etEmail.getText().toString().trim();
            String studentId = binding.etStudentId.getText().toString().trim();
            String password = binding.etPassword.getText().toString().trim();
            String confirmPassword = binding.etConfirmPassword.getText().toString().trim();

            // Validate the input
            if (TextUtils.isEmpty(fullName) || TextUtils.isEmpty(email) || TextUtils.isEmpty(studentId) || TextUtils.isEmpty(password) || TextUtils.isEmpty(confirmPassword)) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!password.equals(confirmPassword)) {
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                return;
            }

            // Create a new student user
            User user = new User(fullName, email, studentId, password, "student");

            // Insert the user into the database
            new Thread(() -> {
                database.userDao().insert(user);
                runOnUiThread(() -> {
                    Toast.makeText(this, "Registration successful", Toast.LENGTH_SHORT).show();
                    // Navigate to the StudentDashboardActivity
                    startActivity(new Intent(this, StudentDashboardActivity.class));
                    finish();
                });
            }).start();
        });

        // Handle the "Login" link click
        binding.tvLogin.setOnClickListener(v -> {
            // Navigate to the StudentLoginActivity
            startActivity(new Intent(this, StudentLoginActivity.class));
            finish();
        });
    }
}