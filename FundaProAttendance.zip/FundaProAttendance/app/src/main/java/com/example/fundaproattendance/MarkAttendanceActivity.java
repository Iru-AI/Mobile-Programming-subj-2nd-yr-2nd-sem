package com.example.fundaproattendance;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import com.example.fundaproattendance.data.AppDatabase;
import com.example.fundaproattendance.databinding.MarkAttendanceLayoutBinding;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MarkAttendanceActivity extends AppCompatActivity {

    private MarkAttendanceLayoutBinding binding;
    private AppDatabase database;
    private String selectedClass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.mark_attendance_layout);

        database = AppDatabase.getDatabase(this);

        // Display today's date
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM dd, yyyy", Locale.getDefault());
        String currentDate = dateFormat.format(new Date());
        binding.currentDate.setText(currentDate);

        // Populate the class spinner
        List<String> classList = new ArrayList<>();
        classList.add("Class A");
        classList.add("Class B");
        classList.add("Class C");
        // You'll need to replace this with actual data from your database
        ArrayAdapter<String> classAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, classList);
        classAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.classSpinner.setAdapter(classAdapter);

        // Handle class selection
        binding.classSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedClass = parent.getItemAtPosition(position).toString();
                // Update the UI based on the selected class (e.g., show a list of students)
                Toast.makeText(MarkAttendanceActivity.this, "Selected class: " + selectedClass, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });

        // Handle "Mark as Present" button click
        binding.btnMarkPresent.setOnClickListener(v -> {
            if (selectedClass != null) {
                // Mark all students in the selected class as present
                // You'll need to implement the database logic here
                binding.attendanceStatus.setText("Attendance Status: Marked as Present");
            } else {
                Toast.makeText(this, "Please select a class", Toast.LENGTH_SHORT).show();
            }
        });

        // Handle "Mark as Absent" button click
        binding.btnMarkAbsent.setOnClickListener(v -> {
            if (selectedClass != null) {
                // Mark all students in the selected class as absent
                // You'll need to implement the database logic here
                binding.attendanceStatus.setText("Attendance Status: Marked as Absent");
            } else {
                Toast.makeText(this, "Please select a class", Toast.LENGTH_SHORT).show();
            }
        });
    }
}