package com.example.fundaproattendance;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.button.MaterialButton;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MarkAttendanceActivity extends AppCompatActivity {

    private TextView currentDateTextView;
    private Spinner classSpinner;
    private MaterialButton markPresentButton;
    private MaterialButton markAbsentButton;
    private TextView attendanceStatusTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mark_attendance_layout);

        // Set up the toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // Initialize views
        currentDateTextView = findViewById(R.id.current_date);
        classSpinner = findViewById(R.id.class_spinner);
        markPresentButton = findViewById(R.id.btn_mark_present);
        markAbsentButton = findViewById(R.id.btn_mark_absent);
        attendanceStatusTextView = findViewById(R.id.attendance_status);

        // Set current date
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM dd, yyyy", Locale.getDefault());
        String currentDate = dateFormat.format(new Date());
        currentDateTextView.setText(currentDate);

        // Set up the class spinner
        setUpClassSpinner();

        // Handle button clicks
        markPresentButton.setOnClickListener(v -> markAttendance("Present"));

        markAbsentButton.setOnClickListener(v -> markAttendance("Absent"));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressedDispatcher.onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setUpClassSpinner() {
        // Sample class data (replace with your actual data)
        String[] classes = {"Class 1", "Class 2", "Class 3", "Class 4", "Class 5"};

        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, classes);

        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // Apply the adapter to the spinner
        classSpinner.setAdapter(adapter);

        // Set a listener to respond to user selections
        classSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedClass = parent.getItemAtPosition(position).toString();
                // Do something with the selected class (e.g., load student data)
                System.out.println("Selected class: " + selectedClass);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Handle the case where nothing is selected
            }
        });
    }

    private void markAttendance(String status) {
        // Get the selected class
        String selectedClass = classSpinner.getSelectedItem().toString();

        // Update the attendance status TextView
        attendanceStatusTextView.setText("Attendance Status: " + status + " for " + selectedClass);

        // Do something with the attendance data (e.g., save to database)
        System.out.println("Marked " + status + " for " + selectedClass);
    }
}