package com.example.fundaproattendance;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import com.example.fundaproattendance.databinding.AdminTeacherLayoutBinding;

public class TeacherAdminDashboardActivity extends AppCompatActivity {

    private AdminTeacherLayoutBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.admin_teacher_layout);

        // TODO: Implement teacher/admin dashboard functionality
    }
}