package com.example.fundaproattendance;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import com.example.fundaproattendance.data.AppDatabase;
import com.example.fundaproattendance.databinding.AdminTeacherLayoutBinding;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class TeacherAdminDashboardActivity extends AppCompatActivity {

    private AdminTeacherLayoutBinding binding;
    private AppDatabase database;
    private Calendar calendar = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.admin_teacher_dashboard_layout);

        database = AppDatabase.getDatabase(this);

        // Set the admin/teacher's name and ID in the welcome card
        // You'll need to retrieve the admin/teacher's data from the database
        // For example, you might pass the admin/teacher ID from the login activity
        // and then query the database to get the admin/teacher's name and ID
        String adminId = "A9876"; // Replace with actual admin ID
        String adminName = "Admin/Teacher"; // Replace with actual admin name
        binding.tvWelcome.setText("Welcome, " + adminName);
        binding.tvAdminId.setText("ID: " + adminId);

        // Handle the "More options" button click
        binding.btnMoreOptions.setOnClickListener(v -> {
            // Toggle the visibility of the hidden options
            if (binding.layoutHiddenOptions.getVisibility() == View.GONE) {
                binding.layoutHiddenOptions.setVisibility(View.VISIBLE);
            } else {
                binding.layoutHiddenOptions.setVisibility(View.GONE);
            }
        });

        // Handle the "Account Settings" button click
        binding.btnAccountSettings.setOnClickListener(v -> {
            // Handle account settings logic here
            Toast.makeText(this, "Account settings clicked", Toast.LENGTH_SHORT).show();
        });

        // Handle the "Logout" button click
        binding.btnLogout.setOnClickListener(v -> {
            // Handle logout logic here
            startActivity(new Intent(this, StudentLoginActivity.class));
            finish();
        });

        // Handle the date selection
        binding.etAttendanceDate.setOnClickListener(v -> {
            // Show a date picker
            DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                    calendar.set(Calendar.YEAR, year);
                    calendar.set(Calendar.MONTH, monthOfYear);
                    calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                    updateDateLabel();
                }
            };

            new DatePickerDialog(TeacherAdminDashboardActivity.this, date, calendar
                    .get(Calendar.YEAR), calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)).show();
        }); // Added closing parenthesis here

        // Handle the "View Attendance" button click
        binding.btnViewAttendance.setOnClickListener(v -> {
            // Handle view attendance logic here
            Toast.makeText(this, "View attendance clicked", Toast.LENGTH_SHORT).show();
        });

        // Handle the "Manage Students" button click
        binding.btnManageStudents.setOnClickListener(v -> {
            // Handle manage students logic here
            Toast.makeText(this, "Manage students clicked", Toast.LENGTH_SHORT).show();
        });

        // Handle the "Create Assignment" button click
        binding.btnCreateAssignment.setOnClickListener(v -> {
            // Handle create assignment logic here
            Toast.makeText(this, "Create assignment clicked", Toast.LENGTH_SHORT).show();
        });
    }

    private void updateDateLabel() {
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        binding.etAttendanceDate.setText(sdf.format(calendar.getTime()));
    }
}