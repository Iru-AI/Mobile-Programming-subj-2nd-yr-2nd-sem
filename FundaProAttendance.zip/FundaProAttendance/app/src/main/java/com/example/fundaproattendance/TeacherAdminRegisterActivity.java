package com.example.fundaproattendance;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import com.example.fundaproattendance.data.AppDatabase;
import com.example.fundaproattendance.data.User;
import com.example.fundaproattendance.databinding.TeacherAdminRegisterLayoutBinding;

public class TeacherAdminRegisterActivity extends AppCompatActivity {

    private TeacherAdminRegisterLayoutBinding binding;
    private AppDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.teacher_admin_register_layout);

        database = AppDatabase.getDatabase(this);

        // Populate the dropdown_role with the options "teacher" and "admin"
        String[] roles = {"teacher", "admin"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, roles);
        binding.dropdownRole.setAdapter(adapter);

        // Handle the "Register" button click
        binding.btnRegister.setOnClickListener(v -> {
            // Get the values from the input fields
            String fullName = binding.etFullName.getText().toString().trim();
            String email = binding.etEmail.getText().toString().trim();
            String password = binding.etPassword.getText().toString().trim();
            String confirmPassword = binding.etConfirmPassword.getText().toString().trim();
            String role = binding.dropdownRole.getText().toString().trim();

            // Validate the input
            if (TextUtils.isEmpty(fullName) || TextUtils.isEmpty(email) || TextUtils.isEmpty(password) || TextUtils.isEmpty(confirmPassword) || TextUtils.isEmpty(role)) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!password.equals(confirmPassword)) {
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                return;
            }

            // Create a new teacher/admin user
            User user = new User(fullName, email, "", password, role);

            // Insert the user into the database
            new Thread(() -> {
                database.userDao().insert(user);
                runOnUiThread(() -> {
                    Toast.makeText(this, "Registration successful", Toast.LENGTH_SHORT).show();
                    // Navigate to the TeacherAdminDashboardActivity
                    startActivity(new Intent(this, TeacherAdminDashboardActivity.class));
                    finish();
                });
            }).start();
        });

        // Handle the "Login" link click
        binding.tvLogin.setOnClickListener(v -> {
            // Navigate to the TeacherAdminLoginActivity
            startActivity(new Intent(this, TeacherAdminLoginActivity.class));
            finish();
        });
    }
}