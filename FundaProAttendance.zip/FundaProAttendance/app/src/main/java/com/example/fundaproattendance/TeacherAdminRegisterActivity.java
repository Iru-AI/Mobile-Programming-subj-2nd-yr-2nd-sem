package com.example.fundaproattendance;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import com.example.fundaproattendance.data.AppDatabase;
import com.example.fundaproattendance.data.User;
import com.example.fundaproattendance.databinding.TeacherAdminRegisterLayoutBinding;

import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.Job;

public class TeacherAdminRegisterActivity extends AppCompatActivity {

    private TeacherAdminRegisterLayoutBinding binding;
    private AppDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.teacher_admin_register_layout);

        database = AppDatabase.getDatabase(this);

        String[] roles = {"Teacher", "Admin"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, roles);
        binding.dropdownRole.setAdapter(adapter);

        binding.btnRegister.setOnClickListener(v -> {
            String fullName = binding.etFullName.getText().toString();
            String email = binding.etEmail.getText().toString();
            String password = binding.etPassword.getText().toString();
            String confirmPassword = binding.etConfirmPassword.getText().toString();
            String role = binding.dropdownRole.getText().toString().toLowerCase();

            if (validateInput(fullName, email, password, confirmPassword, role)) {
                CoroutineScope scope = new CoroutineScope(Dispatchers.getIO());
                Job job = scope.launch(Dispatchers.getIO(), (coroutineScope, continuation) -> {
                    User existingUser = database.userDao().getUserByEmail(email);
                    runOnUiThread(() -> {
                        if (existingUser == null) {
                            User newUser = new User(email, fullName, password, role);
                            database.userDao().insertUser(newUser);
                            Toast.makeText(TeacherAdminRegisterActivity.this, "Registration successful", Toast.LENGTH_SHORT).show();
                            finish();
                        } else {
                            Toast.makeText(TeacherAdminRegisterActivity.this, "Email already exists", Toast.LENGTH_SHORT).show();
                        }
                    });
                    return null;
                });
            }
        });

        binding.tvLogin.setOnClickListener(v -> finish());
    }

    private boolean validateInput(String fullName, String email, String password, String confirmPassword, String role) {
        if (TextUtils.isEmpty(fullName) || TextUtils.isEmpty(email) || TextUtils.isEmpty(password) || TextUtils.isEmpty(confirmPassword) || TextUtils.isEmpty(role)) {
            Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (!password.equals(confirmPassword)) {
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (!role.equals("teacher") && !role.equals("admin")) {
            Toast.makeText(this, "Invalid role selected", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}