package com.example.fundaproattendance;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import com.example.fundaproattendance.data.AppDatabase;
import com.example.fundaproattendance.data.User;
import com.example.fundaproattendance.databinding.TeacherAdminLoginLayoutBinding;

public class TeacherAdminLoginActivity extends AppCompatActivity {

    private TeacherAdminLoginLayoutBinding binding;
    private AppDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.teacher_admin_login_layout);

        database = AppDatabase.getDatabase(this);

        // Handle the "Login" button click
        binding.btnLogin.setOnClickListener(v -> {
            // Get the values from the input fields
            String email = binding.etEmail.getText().toString().trim();
            String password = binding.etPassword.getText().toString().trim();

            // Validate the input
            if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Check if the user exists in the database and if the password is correct
            new Thread(() -> {
                User user = database.userDao().getUserByEmail(email);
                runOnUiThread(() -> {
                    if (user != null && user.getPassword().equals(password) && user.getRole().equals("teacher")) {
                        // Navigate to the TeacherAdminDashboardActivity
                        startActivity(new Intent(this, TeacherAdminDashboardActivity.class));
                        finish();
                    } else {
                        Toast.makeText(this, "Invalid email or password", Toast.LENGTH_SHORT).show();
                    }
                });
            }).start();
        });

        // Handle the "Register" link click
        binding.tvRegister.setOnClickListener(v -> {
            // Navigate to the TeacherAdminRegisterActivity
            startActivity(new Intent(this, TeacherAdminRegisterActivity.class));
            finish();
        });
    }
}