package com.example.fundaproattendance;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import com.example.fundaproattendance.data.AppDatabase;
import com.example.fundaproattendance.data.User;
import com.example.fundaproattendance.databinding.TeacherAdminLoginLayoutBinding;

import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.Job;

public class TeacherAdminLoginActivity extends AppCompatActivity {

    private TeacherAdminLoginLayoutBinding binding;
    private AppDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.teacher_admin_login_layout);

        database = AppDatabase.getDatabase(this);

        binding.btnLogin.setOnClickListener(v -> {
            String email = binding.etEmail.getText().toString();
            String password = binding.etPassword.getText().toString();

            if (validateInput(email, password)) {
                CoroutineScope scope = new CoroutineScope(Dispatchers.getIO());
                Job job = scope.launch(Dispatchers.getIO(), (coroutineScope, continuation) -> {
                    User user = database.userDao().login(email, password);
                    runOnUiThread(() -> {
                        if (user != null && (user.getRole().equals("teacher") || user.getRole().equals("admin"))) {
                            Toast.makeText(TeacherAdminLoginActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(TeacherAdminLoginActivity.this, TeacherAdminDashboardActivity.class));
                            finish();
                        } else {
                            Toast.makeText(TeacherAdminLoginActivity.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
                        }
                    });
                    return null;
                });
            }
        });

        binding.tvRegister.setOnClickListener(v -> {
            startActivity(new Intent(this, TeacherAdminRegisterActivity.class));
        });
    }

    private boolean validateInput(String email, String password) {
        if (TextUtils.isEmpty(email)) {
            binding.etEmail.setError("Email is required");
            return false;
        }
        if (TextUtils.isEmpty(password)) {
            binding.etPassword.setError("Password is required");
            return false;
        }
        return true;
    }
}