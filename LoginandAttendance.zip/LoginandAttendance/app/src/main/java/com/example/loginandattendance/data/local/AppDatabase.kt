package com.example.loginandattendance.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.loginandattendance.data.models.Attendance
import com.example.loginandattendance.data.models.Class
import com.example.loginandattendance.data.models.StudentClassCrossRef
import com.example.loginandattendance.data.models.User

@Database(
    entities = [
        User::class,
        Class::class,
        Attendance::class,
        StudentClassCrossRef::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun classDao(): ClassDao
    abstract fun attendanceDao(): AttendanceDao
}