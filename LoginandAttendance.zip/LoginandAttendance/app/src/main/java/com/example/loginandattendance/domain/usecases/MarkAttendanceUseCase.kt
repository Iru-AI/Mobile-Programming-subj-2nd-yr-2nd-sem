package com.example.loginandattendance.domain.usecases

import com.example.loginandattendance.data.models.Attendance
import com.example.loginandattendance.data.repository.AttendanceRepository
import java.util.Date
import javax.inject.Inject

class MarkAttendanceUseCase @Inject constructor(private val attendanceRepository: AttendanceRepository) {
    suspend operator fun invoke(studentId: Int, classId: Int, date: Date, isPresent: Boolean) {
        try {
            val existingAttendance = attendanceRepository.getAttendanceForStudent(studentId, classId, date)
            if (existingAttendance == null) {
                val attendance = Attendance(studentId = studentId, classId = classId, date = date, isPresent = isPresent)
                attendanceRepository.insertAttendance(attendance)
            } else {
                // Update existing attendance if needed
            }
        } catch (e: Exception) {
            // Handle error
        }
    }
}