package com.example.loginandattendance.presentation.admin

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.loginandattendance.data.models.Class
import com.example.loginandattendance.data.models.User
import com.example.loginandattendance.domain.usecases.AddClassUseCase
import com.example.loginandattendance.domain.usecases.AddStudentUseCase
import com.example.loginandattendance.domain.usecases.GetClassesUseCase
import com.example.loginandattendance.domain.usecases.GetStudentsUseCase
import com.example.loginandattendance.domain.usecases.MarkAttendanceUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.Date
import javax.inject.Inject

@HiltViewModel
class AdminViewModel @Inject constructor(
    private val addClassUseCase: AddClassUseCase,
    private val getClassesUseCase: GetClassesUseCase,
    private val addStudentUseCase: AddStudentUseCase,
    private val getStudentsUseCase: GetStudentsUseCase,
    private val markAttendanceUseCase: MarkAttendanceUseCase
) : ViewModel() {

    private val _classes = MutableStateFlow<List<Class>>(emptyList())
    val classes: StateFlow<List<Class>> = _classes

    private val _students = MutableStateFlow<List<User>>(emptyList())
    val students: StateFlow<List<User>> = _students

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage

    init {
        loadClasses()
    }

    fun loadClasses() {
        viewModelScope.launch {
            try {
                _classes.value = getClassesUseCase()
            } catch (e: Exception) {
                _errorMessage.value = "Error loading classes: ${e.message}"
            }
        }
    }

    fun addClass(className: String) {
        viewModelScope.launch {
            try {
                addClassUseCase(className)
                loadClasses()
            } catch (e: Exception) {
                _errorMessage.value = "Error adding class: ${e.message}"
            }
        }
    }

    fun loadStudents(classId: Int) {
        viewModelScope.launch {
            try {
                _students.value = getStudentsUseCase(classId)
            } catch (e: Exception) {
                _errorMessage.value = "Error loading students: ${e.message}"
            }
        }
    }

    fun addStudent(studentName: String, classId: Int) {
        viewModelScope.launch {
            try {
                addStudentUseCase(studentName, classId)
                loadStudents(classId)
            } catch (e: Exception) {
                _errorMessage.value = "Error adding student: ${e.message}"
            }
        }
    }

    fun markAttendance(studentId: Int, classId: Int, date: Date, isPresent: Boolean) {
        viewModelScope.launch {
            try {
                markAttendanceUseCase(studentId, classId, date, isPresent)
            } catch (e: Exception) {
                _errorMessage.value = "Error marking attendance: ${e.message}"
            }
        }
    }
}