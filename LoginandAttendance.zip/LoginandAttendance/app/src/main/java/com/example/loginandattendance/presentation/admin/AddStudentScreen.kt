package com.example.loginandattendance.presentation.admin

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.loginandattendance.data.models.Class

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddStudentScreen(adminViewModel: AdminViewModel) {
    var studentName by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    var selectedClass by remember { mutableStateOf<Class?>(null) }
    val classes by adminViewModel.classes.collectAsState()
    val errorMessage by adminViewModel.errorMessage.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (errorMessage != null) {
            Text(text = errorMessage!!, color = Color.Red)
        }
        TextField(
            value = studentName,
            onValueChange = { studentName = it },
            label = { Text("Student Name") }
        )
        Spacer(modifier = Modifier.height(16.dp))
        ExposedDropdownMenuBox(
            expanded = expanded,
            onExpandedChange = { expanded = !expanded }
        ) {
            TextField(
                value = selectedClass?.name ?: "Select Class",
                onValueChange = {},
                readOnly = true,
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                modifier = Modifier.menuAnchor()
            )
            ExposedDropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                classes.forEach { classEntity ->
                    DropdownMenuItem(
                        text = { Text(text = classEntity.name) },
                        onClick = {
                            selectedClass = classEntity
                            expanded = false
                        }
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = {
            if (selectedClass != null) {
                adminViewModel.addStudent(studentName, selectedClass!!.id)
            }
        }) {
            Text("Add Student")
        }
    }
}