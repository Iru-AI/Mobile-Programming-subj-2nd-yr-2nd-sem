package com.example.loginandattendance.presentation.student

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.loginandattendance.data.models.Attendance
import com.example.loginandattendance.data.models.Class
import com.example.loginandattendance.domain.usecases.GetAttendanceForStudentUseCase
import com.example.loginandattendance.domain.usecases.GetClassesUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class StudentViewModel @Inject constructor(
    private val getClassesUseCase: GetClassesUseCase,
    private val getAttendanceForStudentUseCase: GetAttendanceForStudentUseCase
) : ViewModel() {

    private val _classes = MutableStateFlow<List<Class>>(emptyList())
    val classes: StateFlow<List<Class>> = _classes

    private val _attendance = MutableStateFlow<List<Attendance>>(emptyList())
    val attendance: StateFlow<List<Attendance>> = _attendance

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage

    private var currentStudentId: Int = 0

    init {
        loadClasses()
    }

    fun loadClasses() {
        viewModelScope.launch {
            try {
                _classes.value = getClassesUseCase()
            } catch (e: Exception) {
                _errorMessage.value = "Error loading classes: ${e.message}"
            }
        }
    }

    fun loadAttendance(studentId: Int) {
        currentStudentId = studentId
        viewModelScope.launch {
            try {
                _attendance.value = getAttendanceForStudentUseCase(studentId)
            } catch (e: Exception) {
                _errorMessage.value = "Error loading attendance: ${e.message}"
            }
        }
    }
}