package com.example.loginandattendance.data.repository

import com.example.loginandattendance.data.local.ClassDao
import com.example.loginandattendance.data.models.Class
import javax.inject.Inject

class ClassRepository @Inject constructor(private val classDao: ClassDao) {
    suspend fun insertClass(classEntity: Class) = classDao.insertClass(classEntity)
    suspend fun getAllClasses(): List<Class> = classDao.getAllClasses()
}