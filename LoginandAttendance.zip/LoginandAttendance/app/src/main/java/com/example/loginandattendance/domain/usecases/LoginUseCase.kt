package com.example.loginandattendance.domain.usecases

import androidx.compose.ui.semantics.password
import com.example.loginandattendance.data.models.User
import com.example.loginandattendance.data.repository.UserRepository
import javax.inject.Inject

class LoginUseCase @Inject constructor(private val userRepository: UserRepository) {
    suspend operator fun invoke(username: String, password: String): Result<User> {
        return try {
            val user = userRepository.getUserByUsername(username)
            if (user != null && user.password == password) {
                Result.success(user)
            } else {
                Result.failure(Exception("Invalid credentials"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}