package com.example.loginandattendance.presentation.admin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.loginandattendance.ui.theme.LoginandAttendanceTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class AdminActivity : ComponentActivity() {
    private val adminViewModel: AdminViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LoginandAttendanceTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    NavHost(navController = navController, startDestination = "classList") {
                        composable("classList") { ClassListScreen(adminViewModel, navController) }
                        composable("addClass") { AddClassScreen(adminViewModel, navController) }
                        composable("studentList") { StudentListScreen(adminViewModel, navController) }
                        composable("addStudent") { AddStudentScreen(adminViewModel, navController) }
                        composable(
                            "markAttendance/{classId}",
                            arguments = listOf(navArgument("classId") { type = NavType.IntType })
                        ) { backStackEntry ->
                            val classId = backStackEntry.arguments?.getInt("classId") ?: 0
                            MarkAttendanceScreen(adminViewModel, classId)
                        }
                    }
                }
            }
        }
    }
}