package com.example.loginandattendance.domain.usecases

import com.example.loginandattendance.data.models.Class
import com.example.loginandattendance.data.repository.ClassRepository
import javax.inject.Inject

class GetClassesUseCase @Inject constructor(private val classRepository: ClassRepository) {
    suspend operator fun invoke(): List<Class> {
        return try {
            classRepository.getClasses()
        } catch (e: Exception) {
            emptyList()
        }
    }
}