package com.example.loginandattendance.domain.usecases

import com.example.loginandattendance.data.models.User
import com.example.loginandattendance.data.repository.UserRepository
import javax.inject.Inject

class AddStudentUseCase @Inject constructor(private val userRepository: UserRepository) {
    suspend operator fun invoke(user: User) {
        userRepository.insertUser(user)
    }
}