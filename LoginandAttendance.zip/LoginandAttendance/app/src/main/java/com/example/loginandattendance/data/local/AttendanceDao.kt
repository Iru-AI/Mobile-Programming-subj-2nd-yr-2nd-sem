package com.example.loginandattendance.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.loginandattendance.data.models.Attendance
import java.util.Date

@Dao
interface AttendanceDao {
    @Insert
    suspend fun insertAttendance(attendance: Attendance)

    @Query("SELECT * FROM attendance WHERE studentId = :studentId AND classId = :classId AND date = :date")
    suspend fun getAttendanceForStudent(studentId: Int, classId: Int, date: Date): Attendance?
}