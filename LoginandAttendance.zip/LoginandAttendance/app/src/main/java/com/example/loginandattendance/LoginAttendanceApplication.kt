package com.example.loginandattendance

import androidx.compose.ui.geometry.isEmpty

import android.app.Application
import androidx.room.Room
import com.example.loginandattendance.data.local.AppDatabase
import com.example.loginandattendance.data.models.User
import com.example.loginandattendance.data.repository.UserRepository
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltAndroidApp
class LoginAttendanceApplication : Application() {
    @Inject
    lateinit var userRepository: UserRepository
    @Inject
    lateinit var appDatabase: AppDatabase

    override fun onCreate() {
        super.onCreate()
        CoroutineScope(Dispatchers.IO).launch {
            // Check if an admin user already exists
            val existingAdmin = appDatabase.userDao().getUsersByRole("admin")
            if (existingAdmin.isEmpty()) {
                // Create a default admin user
                val defaultAdmin = User(username = "admin", password = "password", role = "admin")
                userRepository.insertUser(defaultAdmin)
            }
        }
    }
}