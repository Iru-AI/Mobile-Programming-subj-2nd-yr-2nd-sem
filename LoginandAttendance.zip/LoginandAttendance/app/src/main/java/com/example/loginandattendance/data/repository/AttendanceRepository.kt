package com.example.loginandattendance.data.repository

import com.example.loginandattendance.data.local.AttendanceDao
import com.example.loginandattendance.data.models.Attendance
import java.util.Date
import javax.inject.Inject

class AttendanceRepository @Inject constructor(private val attendanceDao: AttendanceDao) {
    suspend fun insertAttendance(attendance: Attendance) {
        attendanceDao.insertAttendance(attendance)
    }

    suspend fun getAttendanceForStudent(studentId: Int, classId: Int, date: Date): Attendance? {
        return attendanceDao.getAttendanceForStudent(studentId, classId, date)
    }
    suspend fun getAttendanceForStudent(studentId: Int): List<Attendance> {
        return attendanceDao.getAttendanceForStudent(studentId)
    }
}