package com.example.loginandattendance.data.repository

import com.example.loginandattendance.data.models.User

interface UserRepository {
    suspend fun insertUser(user: User)
    suspend fun getAllUsers(): List<User>
    suspend fun getStudentsByClassId(classId: Int): List<User>
}