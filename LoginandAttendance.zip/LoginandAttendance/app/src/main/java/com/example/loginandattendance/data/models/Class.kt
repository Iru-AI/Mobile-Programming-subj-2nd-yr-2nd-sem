package com.example.loginandattendance.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "classes")
data class Class(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val teacherId: Int // ID of the teacher who created the class
)