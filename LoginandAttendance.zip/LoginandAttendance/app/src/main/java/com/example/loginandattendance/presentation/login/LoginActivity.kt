package com.example.loginandattendance.presentation.login

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.loginandattendance.presentation.admin.AdminActivity
import com.example.loginandattendance.presentation.student.StudentActivity
import com.example.loginandattendance.ui.theme.LoginAttendanceSystemTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class LoginActivity : ComponentActivity() {
    private val loginViewModel: LoginViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LoginAttendanceSystemTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    LoginScreen(onLoginSuccess = { role, userId ->
                        when (role) {
                            "admin" -> {
                                val intent = Intent(this, AdminActivity::class.java)
                                startActivity(intent)
                            }
                            "student" -> {
                                val intent = Intent(this, StudentActivity::class.java)
                                intent.putExtra("studentId", userId)
                                startActivity(intent)
                            }
                        }
                    }, loginViewModel = loginViewModel)
                }
            }
        }
    }
}