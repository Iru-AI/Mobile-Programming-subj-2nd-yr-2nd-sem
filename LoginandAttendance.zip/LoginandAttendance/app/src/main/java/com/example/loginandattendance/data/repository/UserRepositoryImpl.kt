package com.example.loginandattendance.data.repository

import com.example.loginandattendance.data.local.UserDao
import com.example.loginandattendance.data.models.User
import javax.inject.Inject

class UserRepositoryImpl @Inject constructor(private val userDao: UserDao) : UserRepository {
    override suspend fun insertUser(user: User) {
        userDao.insertUser(user)
    }

    override suspend fun getAllUsers(): List<User> {
        return userDao.getAllUsers()
    }

    override suspend fun getStudentsByClassId(classId: Int): List<User> {
        return userDao.getStudentsByClassId(classId)
    }
}