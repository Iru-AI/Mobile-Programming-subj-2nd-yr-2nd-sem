package com.example.loginandattendance.domain.usecases

import com.example.loginandattendance.data.models.Attendance
import com.example.loginandattendance.data.repository.AttendanceRepository
import javax.inject.Inject

class GetAttendanceForStudentUseCase @Inject constructor(private val attendanceRepository: AttendanceRepository) {
    suspend operator fun invoke(studentId: Int): List<Attendance> {
        return try {
            attendanceRepository.getAttendanceForStudent(studentId)
        } catch (e: Exception) {
            emptyList()
        }
    }
}