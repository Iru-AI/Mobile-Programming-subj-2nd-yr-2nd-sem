package com.example.loginandattendance.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.loginandattendance.data.models.Class

@Dao
interface ClassDao {
    @Insert
    suspend fun insertClass(classEntity: Class)

    @Query("SELECT * FROM classes")
    suspend fun getAllClasses(): List<Class>
}