package com.example.loginandattendance.presentation.student

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.loginandattendance.data.models.Class

@Composable
fun StudentClassListScreen(studentViewModel: StudentViewModel) {
    val classes by studentViewModel.classes.collectAsState()
    val errorMessage by studentViewModel.errorMessage.collectAsState()
    val navController = rememberNavController()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (errorMessage != null) {
            Text(text = errorMessage!!, color = Color.Red)
        }
        if (classes.isEmpty() && errorMessage == null) {
            Text("No classes available.")
        } else {
            LazyColumn {
                items(classes) { classEntity ->
                    ClassItem(classEntity = classEntity, navController = navController)
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = {
            navController.navigate("studentAttendance")
        }) {
            Text("View Attendance")
        }
    }
}

@Composable
fun ClassItem(classEntity: Class, navController: NavController) {
    Column(modifier = Modifier
        .padding(8.dp)
        .clickable {
            // You can add navigation to class details here if needed
        }) {
        Text(text = classEntity.name)
        Spacer(modifier = Modifier.height(4.dp))
    }
}