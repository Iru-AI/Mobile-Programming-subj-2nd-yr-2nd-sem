package com.example.loginandattendance.domain.usecases

import com.example.loginandattendance.data.models.User
import com.example.loginandattendance.data.repository.UserRepository
import javax.inject.Inject

class GetStudentsUseCase @Inject constructor(private val userRepository: UserRepository) {
    suspend operator fun invoke(classId: Int): List<User> {
        return userRepository.getStudentsByClassId(classId)
    }
}