package com.example.loginandattendance.domain.usecases

import com.example.loginandattendance.data.models.Class
import com.example.loginandattendance.data.repository.ClassRepository
import javax.inject.Inject

class AddClassUseCase @Inject constructor(private val classRepository: ClassRepository) {
    suspend operator fun invoke(classEntity: Class) {
        classRepository.insertClass(classEntity)
    }
}