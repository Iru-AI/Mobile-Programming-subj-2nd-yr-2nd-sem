package com.example.loginandattendance.presentation.admin

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.loginandattendance.data.models.Class

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClassListScreen(adminViewModel: AdminViewModel, navController: NavController) {
    val classes by adminViewModel.classes.collectAsState()

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { navController.navigate("addClass") }) {
                Icon(Icons.Filled.Add, "Add")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(innerPadding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (classes.isEmpty()) {
                Text("No classes added yet.")
            } else {
                LazyColumn {
                    items(classes) { classEntity ->
                        ClassItem(classEntity = classEntity, navController = navController)
                    }
                }
            }
        }
    }
}

@Composable
fun ClassItem(classEntity: Class, navController: NavController) {
    Column(modifier = Modifier
        .padding(8.dp)
        .clickable { navController.navigate("markAttendance/${classEntity.id}") }) {
        Text(text = classEntity.name)
        Spacer(modifier = Modifier.height(4.dp))
    }
}