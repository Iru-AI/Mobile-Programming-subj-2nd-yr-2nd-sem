package com.example.loginandattendance.presentation.admin

import android.app.DatePickerDialog
import android.widget.DatePicker
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.loginandattendance.data.models.Class
import com.example.loginandattendance.data.models.User
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MarkAttendanceScreen(adminViewModel: AdminViewModel) {
    var expandedClass by remember { mutableStateOf(false) }
    var selectedClass by remember { mutableStateOf<Class?>(null) }
    val classes by adminViewModel.classes.collectAsState()
    val students by adminViewModel.students.collectAsState()
    val errorMessage by adminViewModel.errorMessage.collectAsState()

    var selectedDate by remember { mutableStateOf(Date()) }
    val calendar = Calendar.getInstance()
    val year = calendar.get(Calendar.YEAR)
    val month = calendar.get(Calendar.MONTH)
    val day = calendar.get(Calendar.DAY_OF_MONTH)
    val datePicker = DatePickerDialog(
        LocalContext.current,
        { _: DatePicker, selectedYear: Int, selectedMonth: Int, selectedDay: Int ->
            selectedDate = Calendar.getInstance().apply {
                set(selectedYear, selectedMonth, selectedDay)
            }.time
        }, year, month, day
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (errorMessage != null) {
            Text(text = errorMessage!!, color = Color.Red)
        }
        Button(onClick = { datePicker.show() }) {
            Text(text = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(selectedDate))
        }
        Spacer(modifier = Modifier.height(16.dp))
        ExposedDropdownMenuBox(
            expanded = expandedClass,
            onExpandedChange = { expandedClass = !expandedClass }
        ) {
            TextField(
                value = selectedClass?.name ?: "Select Class",
                onValueChange = {},
                readOnly = true,
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedClass) },
                modifier = Modifier.menuAnchor()
            )
            ExposedDropdownMenu(
                expanded = expandedClass,
                onDismissRequest = { expandedClass = false }
            ) {
                classes.forEach { classEntity ->
                    DropdownMenuItem(
                        text = { Text(text = classEntity.name) },
                        onClick = {
                            selectedClass = classEntity
                            expandedClass = false
                            adminViewModel.loadStudents(classEntity.id)
                        }
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        LazyColumn {
            items(students) { student ->
                AttendanceItem(student = student, selectedClass = selectedClass, selectedDate = selectedDate, adminViewModel = adminViewModel)
            }
        }
    }
}

@Composable
fun AttendanceItem(student: User, selectedClass: Class?, selectedDate: Date, adminViewModel: AdminViewModel) {
    var isPresent by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = student.name, modifier = Modifier.weight(1f))
        Checkbox(
            checked = isPresent,
            onCheckedChange = {
                isPresent = it
                if (selectedClass != null) {
                    adminViewModel.markAttendance(student.id, selectedClass.id, selectedDate, isPresent)
                }
            }
        )
    }
}