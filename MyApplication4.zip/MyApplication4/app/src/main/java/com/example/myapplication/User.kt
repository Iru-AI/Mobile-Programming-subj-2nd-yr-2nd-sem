package com.example.myapplication

data class ResponseModel(val success: Boolean, val message: String)
